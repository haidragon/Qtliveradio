#include "onlinedao.h"

OnlineDao::OnlineDao()
{

}

OnlineDao::~OnlineDao()
{

}

